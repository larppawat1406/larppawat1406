-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 25, 2019 at 10:57 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `itsupport`
--

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `requestnum` int(11) NOT NULL COMMENT 'เลขที่รายการ',
  `requester` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `requestdate` date NOT NULL,
  `requestcase` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `requestnote` text COLLATE utf8_unicode_ci NOT NULL,
  `servicedate` date NOT NULL,
  `servicenote` text COLLATE utf8_unicode_ci NOT NULL,
  `requeststatus` tinyint(4) NOT NULL,
  `supporter` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`requestnum`, `requester`, `requestdate`, `requestcase`, `requestnote`, `servicedate`, `servicenote`, `requeststatus`, `supporter`) VALUES
(1, 'พี่เอ๋ บัญชี', '2019-10-26', 'เครื่องพิมพ์', 'หมึกจาง', '2019-10-31', 'ตลับหมึกเสีย\r\nเปลี่ยนตลับหมึกใหม่', 3, 'Bill gates'),
(2, 'ออย การเงิน', '2019-10-26', 'คอมพิวเตอร์', 'เปิดไม่ติด', '2019-10-28', 'สาย ACC ขาดใน\r\nเปลี่ยนสาย ACC', 3, 'Steve jobs'),
(3, 'พี่ศรี บุคคล', '2019-10-26', 'โปรแกรม', 'เข้าระบบเงินเดือนไม่ได้', '2019-10-30', 'ถอนการติดตั้ง\r\nลงโปรแกรมใหม่', 3, 'Mark Zuckerberg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`requestnum`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `requestnum` int(11) NOT NULL AUTO_INCREMENT COMMENT 'เลขที่รายการ', AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
