<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>IT Support System</title>
    </head>
    <body>
        <h1>แบบฟอร์มแจ้งซ่อมคอมพิวเตอร์</h1>
        <form action="insert.php" method="POST">
            ผู้แจ้ง : <input type="text" name="requester" value="" required /><br />
            แจ้งปัญหา :<br />
            <input type="radio" name="requestcase" value="คอมพิวเตอร์" checked="checked" /> คอมพิวเตอร์<br />
            <input type="radio" name="requestcase" value="เครื่องพิมพ์" /> เครื่องพิมพ์<br />
            <input type="radio" name="requestcase" value="อินเทอร์เน็ต" /> อินเทอร์เน็ต<br />
            <input type="radio" name="requestcase" value="โปรแกรม" /> โปรแกรม<br />
            <input type="radio" name="requestcase" value="ระบบสำรสนเทศ" /> ระบบสำรสนเทศ<br />
            <input type="radio" name="requestcase" value="อื่นๆ" /> อื่นๆ (โปรดระบุไว้ในช่องหมายเหตุ)<br />
            หมายเหตุ : <br />
            <textarea name="requestnote" rows="4" cols="40"></textarea><br /><br />
            <button type="submit">Submit</button>
        </form>
    </body>
</html>
