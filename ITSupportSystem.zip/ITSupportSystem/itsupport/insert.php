<!DOCTYPE html>
<?php
require './mysql/config.php';
$requester = $_POST['requester'];
$requestcase = $_POST['requestcase'];
$requestnote = $_POST['requestnote'];
$requestdate = date("Y-m-d");
$sql = "INSERT INTO requests(requester,requestdate,requestcase,requestnote,requeststatus) "
        . "VALUES('$requester','$requestdate','$requestcase','$requestnote','1')";
$result = $conn->query($sql);
$v1 = ($result == 1) ? 1 : 0;
?>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>IT Support System</title>
    </head>
    <body>
        <script>
            var v1 =<?php echo $v1; ?>;
            if(v1==1){
                alert('การดำเนินการเสร็จสิ้น');
                window.location.replace("index.php");
            }else{
                alert('การดำเนินการล้มเหลว');
                window.history.back();
            }
        </script>
    </body>
</html>
