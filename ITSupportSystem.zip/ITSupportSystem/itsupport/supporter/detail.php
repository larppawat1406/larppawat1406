<!DOCTYPE html>
<?php
require '../mysql/config.php';
$requestnum = (isset($_GET['requestnum'])) ? $_GET['requestnum'] : "";
$sql = "SELECT * FROM requests WHERE requestnum = '$requestnum'";
$result = $conn->query($sql);
$row = $result->fetch_array(MYSQLI_ASSOC);
$requester = $row['requester'];
$requestdate = $row['requestdate'];
$requestcase = $row['requestcase'];
$requestnote = $row['requestnote'];
$servicedate = $row['servicedate'];
$servicenote = $row['servicenote'];
$requeststatus = $row['requeststatus'];
$supporter = $row['supporter'];
?>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>IT Support System</title>
    </head>
    <body>
        <h1>ข้อมูลการแจ้งซ่อมคอมพิวเตอร์</h1>
        วันที่แจ้ง : <?php echo $requestdate; ?><br />
        ผู้แจ้ง : <?php echo $requester; ?><br />
        แจ้งปัญหา : <?php echo $requestcase; ?><br />
        หมายเหตุการแจ้ง :
        <div style="padding-left: 5px;">
            <?php echo preg_replace("/\r?\n/", "<br />", $requestnote); ?>
        </div><br />
        สถานะ : <?php echo $requeststatusname[$requeststatus]; ?><br />
        วันที่ให้บริการ : <?php echo $servicedate; ?><br />
        หมายเหตุการบริการ :
        <div style="padding-left: 5px;">
            <?php echo preg_replace("/\r?\n/", "<br />", $servicenote); ?>
        </div><br />
        ผู้ให้บริการ : <?php echo $supporter; ?><br /><br />
        <a href="form.php?requestnum=<?php echo $requestnum; ?>">Update</a>
        <a href="index.php">Back</a>
    </body>
</html>
