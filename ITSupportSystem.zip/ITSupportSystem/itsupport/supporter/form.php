<!DOCTYPE html>
<?php
require '../mysql/config.php';
$requestnum = (isset($_GET['requestnum'])) ? $_GET['requestnum'] : "";
$sql = "SELECT * FROM requests WHERE requestnum = '$requestnum'";
$result = $conn->query($sql);
$row = $result->fetch_array(MYSQLI_ASSOC);
$requester = $row['requester'];
$requestdate = $row['requestdate'];
$requestcase = $row['requestcase'];
$requestnote = $row['requestnote'];
$servicedate = $row['servicedate'];
$servicenote = $row['servicenote'];
$requeststatus = $row['requeststatus'];
$supporter = $row['supporter'];
?>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>IT Support System</title>
    </head>
    <body>
        <h1>แบบฟอร์มบันทึกผลการให้บริการทางไอที</h1>
        <form action="update.php" method="POST">
            <input type="hidden" name="requestnum" value="<?php echo $requestnum; ?>" />
            วันที่แจ้ง : <input type="text" value="<?php echo $requestdate; ?>" readonly /><br />
            ผู้แจ้ง : <input type="text" value="<?php echo $requester; ?>" readonly /><br />
            แจ้งปัญหา : <input type="text" value="<?php echo $requestcase; ?>" readonly /><br />
            หมายเหตุการแจ้ง :<br />
            <textarea rows="4" cols="40" readonly><?php echo $requestnote; ?></textarea><br /><br />
            สถานะ : 
            <select name="requeststatus" id="requeststatus">
                <option value="1">ร้องขอ</option>
                <option value="2">ไม่สำเร็จ</option>
                <option value="3">เสร็จสิ้น</option>
            </select><br />
            วันที่ให้บริการ : <input type="date" name="servicedate" value="<?php echo $servicedate; ?>" required /><br />
            หมายเหตุการบริการ :<br />
            <textarea name="servicenote" rows="4" cols="40"><?php echo $servicenote; ?></textarea><br />
            ผู้ให้บริการ : <input type="text" name="supporter" value="<?php echo $supporter; ?>" required /><br /><br />
            <button type="submit">Update</button>
            <button type="button" onclick="window.history.back();">Back</button>
        </form>
        <script>
            document.getElementById('requeststatus').value = '<?php echo $requeststatus; ?>';
        </script>
    </body>
</html>
