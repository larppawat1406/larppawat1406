<!DOCTYPE html>
<?php
require '../mysql/config.php';
$sql = "SELECT * FROM requests ORDER BY requeststatus ASC, requestdate DESC, requestnum ASC";
$result = $conn->query($sql);
?>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>IT Support System</title>
    </head>
    <body>
        <h1>รายการแจ้งซ่อมคอมพิวเตอร์</h1>
        <table border="1" cellspacing="0" cellpadding="5">
            <thead>
                <tr style="background-color: skyblue;">
                    <th>วันที่แจ้ง</th>
                    <th>ผู้แจ้ง</th>
                    <th>แจ้งปัญหา</th>
                    <th>สถานะ</th>
                    <th>วันที่ให้บริการ</th>
                    <th>ผู้ให้บริการ</th>
                    <th>ดูข้อมูล</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
                    $requestnum = $row['requestnum'];
                    $requester = $row['requester'];
                    $requestdate = $row['requestdate'];
                    $requestcase = $row['requestcase'];
                    $servicedate = $row['servicedate'];
                    $requeststatus=$row['requeststatus'];
                    $supporter = $row['supporter'];
                    ?>
                    <tr>
                        <td><?php echo $requestdate;?></td>
                        <td><?php echo $requester;?></td>
                        <td><?php echo $requestcase;?></td>
                        <td><?php echo $requeststatusname[$requeststatus];?></td>
                        <td><?php echo $servicedate;?></td>
                        <td><?php echo $supporter;?></td>
                        <td><a href="detail.php?requestnum=<?php echo $requestnum;?>">Detail</a></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

    </body>
</html>
