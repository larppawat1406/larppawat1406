<!DOCTYPE html>
<?php
require '../mysql/config.php';
$requestnum = $_POST['requestnum'];
$requeststatus = $_POST['requeststatus'];
$servicedate = $_POST['servicedate'];
$servicenote = $_POST['servicenote'];
$supporter = $_POST['supporter'];
$sql = "UPDATE requests SET "
        . "servicedate = '$servicedate', "
        . "servicenote = '$servicenote', "
        . "requeststatus = '$requeststatus', "
        . "supporter = '$supporter' "
        . "WHERE requestnum = '$requestnum'";
$result = $conn->query($sql);
$v1 = ($result == 1) ? 1 : 0;
?>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>IT Support System</title>
    </head>
    <body>
        <script>
            var v1 =<?php echo $v1; ?>;
            if (v1 == 1) {
                alert('การดำเนินการเสร็จสิ้น');
                window.location.replace("detail.php?requestnum=<?php echo $requestnum; ?>");
            } else {
                alert('การดำเนินการล้มเหลว');
                window.history.back();
            }
        </script>
    </body>
</html>
